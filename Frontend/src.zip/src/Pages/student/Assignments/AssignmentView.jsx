import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { 
  FileText, 
  Award, 
  CheckCircle, 
  AlertCircle, 
  Loader,
  Download,
  ArrowLeft,
  User,
  GraduationCap
} from "lucide-react";
import { toast } from 'react-toastify';

export default function AssignmentView() {
  const { assignmentId } = useParams();
  const navigate = useNavigate();
  const token = localStorage.getItem("accessToken");
  const API_BASE = import.meta.env.VITE_API_TEACHER || "http://localhost:5001/api/teacher";

  const [submission, setSubmission] = useState(null);
  const [marks, setMarks] = useState("");
  const [remarks, setRemarks] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  /* =========================
     LOAD SUBMISSION
  ========================= */
  const loadSubmission = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const res = await axios.get(
        `${API_BASE}/assignments/${assignmentId}/submission`, // Fixed endpoint for single submission
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const data = res.data.submission || res.data;
      setSubmission(data);
      setMarks(data.score?.toString() || "");
      setRemarks(data.remarks || "");
    } catch (err) {
      console.error("Failed to load submission", err);
      const errorMsg = err.response?.data?.message || "Failed to load submission. Please try again.";
      setError(errorMsg);
      toast.error(errorMsg, { 
        autoClose: 4000,
        position: "top-center",
        theme: "colored"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (assignmentId && token) loadSubmission();
  }, [assignmentId, token]);

  /* =========================
     VALIDATE MARKS
  ========================= */
  const validateMarks = () => {
    if (marks.trim() === "") {
      toast.error("Please enter marks", { 
        autoClose: 2000,
        position: "top-center",
        theme: "colored"
      });
      return false;
    }
    
    const numMarks = Number(marks);
    if (isNaN(numMarks) || numMarks < 0) {
      toast.error("Please enter a valid mark (non-negative number)", { 
        autoClose: 3000,
        position: "top-center",
        theme: "colored"
      });
      return false;
    }
    
    if (submission?.maxMarks && numMarks > submission.maxMarks) {
      toast.warn(`Marks cannot exceed maximum (${submission.maxMarks})`, { 
        autoClose: 3000,
        position: "top-center",
        theme: "colored"
      });
      return false;
    }
    
    return true;
  };

  /* =========================
     GRADE SUBMISSION
  ========================= */
  const gradeSubmission = async () => {
    if (!validateMarks()) return;
    
    try {
      setSaving(true);
      
      await axios.put(
        `${API_BASE}/submissions/${submission._id}/grade`, // Corrected endpoint
        {
          score: Number(marks),
          remarks: remarks.trim(),
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      toast.success("✅ Marks published successfully!", {
        autoClose: 3000,
        position: "top-center",
        theme: "colored"
      });
      
      // Refresh data
      await loadSubmission();
    } catch (err) {
      console.error("Failed to grade assignment", err);
      const errorMsg = err.response?.data?.message || "Failed to save marks. Please try again.";
      toast.error(errorMsg, { 
        autoClose: 4000,
        position: "top-center",
        theme: "colored"
      });
    } finally {
      setSaving(false);
    }
  };

  /* =========================
     DOWNLOAD PDF
  ========================= */
  const downloadPDF = () => {
    if (!submission?.pdfUrl) return;
    
    const link = document.createElement('a');
    link.href = submission.pdfUrl.startsWith('http') 
      ? submission.pdfUrl 
      : `https://server.myshikshana.in${submission.pdfUrl}`;
    link.download = `Assignment_${submission.student?.name || 'submission'}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.info("PDF downloaded successfully", {
      autoClose: 2000,
      position: "top-center",
      theme: "colored"
    });
  };

  /* =========================
     SKELETON LOADER
  ========================= */
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-4xl w-full animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
          <div className="h-96 bg-gray-200 rounded-xl mb-6"></div>
          <div className="space-y-4">
            <div className="h-10 bg-gray-200 rounded w-1/4"></div>
            <div className="h-40 bg-gray-200 rounded-xl"></div>
            <div className="h-12 bg-gray-200 rounded-lg w-1/3"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error && !submission) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="flex justify-center mb-4">
            <AlertCircle className="w-16 h-16 text-rose-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Submission Unavailable</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-700 hover:from-indigo-700 hover:to-purple-800 text-white rounded-xl font-semibold shadow-md hover:shadow-lg transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Go Back
          </button>
        </div>
      </div>
    );
  }

  if (!submission) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-2xl bg-indigo-50 mb-4">
            <FileText className="h-8 w-8 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">No Submission Found</h2>
          <p className="text-gray-600 max-w-md mx-auto mb-6">
            This assignment submission could not be located. It may have been removed or you may not have permission to view it.
          </p>
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors"
          >
            Return to Submissions
          </button>
        </div>
      </div>
    );
  }

  /* =========================
     RENDER
  ========================= */
  const isGraded = submission.status === "graded";
  const studentName = 
    submission.student?.fullName || 
    submission.student?.name || 
    `${submission.student?.firstName || ""} ${submission.student?.lastName || ""}`.trim() || 
    "Student";

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 font-medium mb-4 transition-colors"
            aria-label="Back to submissions"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Submissions
          </button>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-indigo-100 p-3 rounded-2xl">
                <Award className="w-8 h-8 text-indigo-600" />
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">
              Assignment Review
            </h1>
            <p className="text-gray-600 max-w-2xl mx-auto mt-2">
              Review and grade the student's submission. Provide constructive feedback to support their learning journey.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Student Info Card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-5 border-b border-gray-100">
                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 rounded-full bg-indigo-100 flex items-center justify-center mb-3">
                    <span className="text-2xl font-bold text-indigo-700">
                      {studentName.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-gray-900">{studentName}</h2>
                  <p className="text-gray-600 mt-1 flex items-center gap-1">
                    <GraduationCap className="w-4 h-4" />
                    {submission.student?.email || "student@example.com"}
                  </p>
                </div>
              </div>
              
              <div className="p-5 space-y-4">
                <div className="border-t pt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Assignment</span>
                    <span className="font-medium text-gray-800">{submission.assignment?.title || "Untitled Assignment"}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Submitted</span>
                    <span className="font-medium text-gray-800">
                      {submission.submittedAt 
                        ? new Date(submission.submittedAt).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })
                        : "N/A"}
                    </span>
                  </div>
                  {submission.assignment?.maxMarks && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Max Marks</span>
                      <span className="font-bold text-indigo-600">{submission.assignment.maxMarks}</span>
                    </div>
                  )}
                </div>
                
                {isGraded && (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-bold text-green-800">Graded</span>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-700">{submission.score}</div>
                      <div className="text-sm text-green-600 mt-1">Marks Awarded</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* PDF Viewer & Grading Section */}
          <div className="lg:col-span-2 space-y-8">
            {/* PDF Viewer */}
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-6 h-6 text-indigo-600" />
                  <h2 className="text-xl font-bold text-gray-900">Submitted Assignment</h2>
                </div>
                <button
                  onClick={downloadPDF}
                  className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                  aria-label="Download PDF"
                >
                  <Download className="w-4 h-4" />
                  Download PDF
                </button>
              </div>
              
              <div className="p-4 bg-gray-50">
                <div className="border-2 border-dashed border-gray-200 rounded-xl overflow-hidden bg-white hover:border-indigo-300 transition-colors">
                  <iframe
                    src={submission.pdfUrl?.startsWith('http') 
                      ? submission.pdfUrl 
                      : `https://server.myshikshana.in${submission.pdfUrl}`}
                    title={`Assignment submission by ${studentName}`}
                    className="w-full h-[650px] md:h-[700px] lg:h-[800px]"
                    loading="lazy"
                  />
                </div>
                <p className="mt-3 text-xs text-gray-500 text-center">
                  Use the PDF viewer controls to navigate through the document
                </p>
              </div>
            </div>

            {/* Grading Section */}
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <div className={`px-6 py-4 border-b ${
                isGraded ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'
              }`}>
                <div className="flex items-center gap-3">
                  {isGraded ? (
                    <>
                      <CheckCircle className="w-6 h-6 text-green-600" />
                      <h2 className="text-xl font-bold text-green-800">Assignment Graded</h2>
                    </>
                  ) : (
                    <>
                      <Award className="w-6 h-6 text-amber-600" />
                      <h2 className="text-xl font-bold text-amber-800">Grade Assignment</h2>
                    </>
                  )}
                </div>
              </div>
              
              <div className="p-6">
                {isGraded ? (
                  <div className="space-y-4">
                    <div className="bg-green-50 border border-green-200 rounded-xl p-5">
                      <div className="flex items-start gap-3">
                        <div className="mt-1 p-2 bg-green-100 rounded-lg">
                          <CheckCircle className="w-5 h-5 text-green-700" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-bold text-green-800 mb-1">Grading Complete</h3>
                          <p className="text-green-700">
                            This assignment has been graded and feedback has been provided to the student.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-white border border-green-200 rounded-lg p-4">
                        <p className="text-sm text-gray-600 mb-1">Marks Awarded</p>
                        <p className="text-3xl font-bold text-green-700">{submission.score}</p>
                      </div>
                      <div className="bg-white border border-green-200 rounded-lg p-4">
                        <p className="text-sm text-gray-600 mb-1">Maximum Marks</p>
                        <p className="text-3xl font-bold text-gray-800">{submission.assignment?.maxMarks || 'N/A'}</p>
                      </div>
                    </div>
                    
                    {submission.remarks && (
                      <div className="bg-white border border-green-200 rounded-lg p-4">
                        <p className="text-sm text-gray-600 mb-2 flex items-center gap-1">
                          <MessageSquare className="w-4 h-4 text-green-600" />
                          Instructor Feedback
                        </p>
                        <p className="text-gray-800 italic leading-relaxed">{submission.remarks}</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-5">
                    <div>
                      <label htmlFor="marks" className="block text-sm font-medium text-gray-700 mb-1">
                        Marks Awarded <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="marks"
                          type="number"
                          min="0"
                          max={submission.assignment?.maxMarks || 100}
                          value={marks}
                          onChange={(e) => setMarks(e.target.value)}
                          placeholder={`e.g., ${submission.assignment?.maxMarks || 100}`}
                          className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                          aria-required="true"
                        />
                        {submission.assignment?.maxMarks && (
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-500">
                            / {submission.assignment.maxMarks}
                          </div>
                        )}
                      </div>
                      <p className="mt-1 text-xs text-gray-500">
                        Enter marks between 0 and {submission.assignment?.maxMarks || 'maximum'}
                      </p>
                    </div>
                    
                    <div>
                      <label htmlFor="remarks" className="block text-sm font-medium text-gray-700 mb-1">
                        Feedback (Optional but Recommended)
                      </label>
                      <textarea
                        id="remarks"
                        value={remarks}
                        onChange={(e) => setRemarks(e.target.value)}
                        placeholder="Provide constructive feedback to help the student improve. Highlight strengths and suggest areas for growth..."
                        rows={5}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all resize-y"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Feedback will be visible to the student after grading
                      </p>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2 border-t border-gray-100">
                      <div className="flex items-center gap-2 text-sm text-amber-700 bg-amber-50 px-3 py-2 rounded-lg">
                        <AlertCircle className="w-4 h-4" />
                        <span>Student will receive notification after publishing</span>
                      </div>
                      <button
                        onClick={gradeSubmission}
                        disabled={saving || isGraded}
                        className={`w-full sm:w-auto px-6 py-3 rounded-xl font-medium text-base transition-all flex items-center justify-center gap-2 shadow ${
                          saving || isGraded
                            ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                            : "bg-gradient-to-r from-indigo-600 to-purple-700 hover:from-indigo-700 hover:to-purple-800 text-white shadow-md hover:shadow-lg"
                        }`}
                      >
                        {saving ? (
                          <>
                            <Loader className="w-5 h-5 animate-spin" />
                            Publishing...
                          </>
                        ) : (
                          <>
                            <Award className="w-5 h-5" />
                            Publish Marks & Feedback
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper component for feedback icon
const MessageSquare = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.706.052 1.414.098 2.125.137v.75M21 3.75h-6.75a1.5 1.5 0 00-1.061.439L10.5 6.479A1.5 1.5 0 0010.061 7.5H3.75A1.5 1.5 0 002.25 9v9a1.5 1.5 0 001.5 1.5h15a1.5 1.5 0 001.5-1.5V9a1.5 1.5 0 00-1.5-1.5h-6.75a1.5 1.5 0 01-1.061-.439l-2.689-2.267a1.5 1.5 0 01-.439-1.061z" />
  </svg>
);
import React, { useRef, useState } from "react";
import axios from "axios";
import { Video, UploadCloud, StopCircle, Mic, Monitor, ArrowLeft } from "lucide-react";

export default function RecorderPage() {
  const videoRef = useRef(null);
  const [recorder, setRecorder] = useState(null);
  const [videoFile, setVideoFile] = useState(null);
  const [recording, setRecording] = useState(false);

  const API = `${import.meta.env.VITE_BASE_URL}/api/teacher`;
  const token = localStorage.getItem("accessToken");

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true,
      });

      videoRef.current.srcObject = stream;
      const rec = new MediaRecorder(stream);
      setRecorder(rec);

      const chunks = [];
      rec.ondataavailable = (e) => chunks.push(e.data);

      rec.onstop = () => {
        const blob = new Blob(chunks, { type: "video/webm" });
        setVideoFile(blob);
        videoRef.current.srcObject = null;
        videoRef.current.src = URL.createObjectURL(blob);
      };

      rec.start();
      setRecording(true);
    } catch (err) {
      console.error("Screen capture failed", err);
      alert("Could not start recording. Please allow screen access.");
    }
  };

  const stopRecording = () => {
    recorder.stop();
    recorder.stream.getTracks().forEach((t) => t.stop());
    setRecording(false);
  };

  const uploadVideo = async () => {
    if (!videoFile) return alert("No recording found");

    const form = new FormData();
    form.append("video", videoFile);

    try {
      await axios.post(`${API}/recorder/upload`, form, {
        headers: { Authorization: `Bearer ${token}` },
      });
      alert("Video uploaded successfully");
      setVideoFile(null);
      videoRef.current.src = "";
    } catch (err) {
      console.error(err);
      alert("Upload failed");
    }
  };

  return (
    <div className="h-screen flex flex-col bg-slate-900 text-white font-sans">
      {/* HEADER (Dark Theme) */}
      <header className="bg-slate-800 border-b border-slate-700 px-6 py-4 shrink-0 flex items-center justify-between">
        <div className="flex items-center gap-4">
           <div className="p-2 bg-red-500/20 text-red-400 rounded-lg">
             <Video className="w-5 h-5" />
           </div>
           <div>
             <h1 className="text-lg font-bold">Studio Recorder</h1>
             <p className="text-xs text-slate-400">Screen & Video Capture</p>
           </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        
        {/* BACKGROUND DECORATION */}
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>

        {/* VIDEO CONTAINER */}
        <div className="relative w-full max-w-5xl aspect-video bg-black rounded-xl shadow-2xl overflow-hidden ring-1 ring-white/10 z-10">
          <video ref={videoRef} controls className="w-full h-full object-contain" />
          
          {/* RECORDING INDICATOR */}
          {recording && (
            <div className="absolute top-4 right-4 flex items-center gap-2 bg-red-600/90 px-3 py-1.5 rounded-full shadow-lg animate-pulse">
              <div className="w-3 h-3 bg-white rounded-full"></div>
              <span className="text-xs font-bold tracking-wider uppercase">Recording</span>
            </div>
          )}
          
          {!videoRef.current?.src && !recording && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 bg-slate-800">
              <Monitor className="w-16 h-16 mb-4 opacity-50" />
              <p className="text-lg font-medium">Ready to Record</p>
            </div>
          )}
        </div>

        {/* CONTROLS */}
        <div className="mt-8 flex gap-4 z-10">
          {!recording ? (
            <button
              onClick={startRecording}
              className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-500 rounded-lg font-semibold shadow-lg shadow-indigo-900/50 transition-all transform hover:scale-105"
            >
              <Monitor className="w-5 h-5" /> Start Recording
            </button>
          ) : (
            <button
              onClick={stopRecording}
              className="flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-500 rounded-lg font-semibold shadow-lg shadow-red-900/50 transition-all"
            >
              <StopCircle className="w-5 h-5" /> Stop Recording
            </button>
          )}

          {videoFile && (
            <button
              onClick={uploadVideo}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 rounded-lg font-semibold shadow-lg shadow-emerald-900/50 transition-all"
            >
              <UploadCloud className="w-5 h-5" /> Upload Video
            </button>
          )}
        </div>
      </main>
    </div>
  );
}
import React, { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

const API = import.meta.env.VITE_API_AUTH || "https://auth.myshikshana.in/api/auth";
// const API = "http://localhost:5000/api/auth";
const TOKEN_KEY = "accessToken";

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  /* ===================== AXIOS INTERCEPTOR ===================== */
  useEffect(() => {
    const interceptor = axios.interceptors.request.use((config) => {
      const token = localStorage.getItem(TOKEN_KEY);
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });

    return () => axios.interceptors.request.eject(interceptor);
  }, []);

  /* ===================== INIT AUTH ===================== */
  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser && savedUser !== "undefined") {
      try {
        setUser(JSON.parse(savedUser));
      } catch {
        localStorage.removeItem("user");
      }
    }
    setLoading(false);
  }, []);

  /* ===================== LOGIN ===================== */
  const login = async (email, password) => {

    // 🔥🔥🔥 MISSING PART (ADDED)
    const isAdminLogin = email.endsWith("@admin.com"); 
    // or any rule you use to identify admin

    const loginURL = isAdminLogin
      ? `${API}/admin/login`
      : `${API}/login`;

    const res = await axios.post(
      loginURL,
      { email, password },
      { withCredentials: true }
    );

    const accessToken = res.data.token || res.data.accessToken;
    const user = res.data.user;

    if (!accessToken || !user) {
      throw new Error("Invalid auth response");
    }

    localStorage.setItem(TOKEN_KEY, accessToken);
    localStorage.setItem("user", JSON.stringify(user));
    setUser(user);

    return { accessToken, user };
  };

  /* ===================== REGISTER ===================== */
  const register = async (name, email, password, role) => {
    const res = await axios.post(
      `${API}/register`,
      { name, email, password, role },
      { withCredentials: true }
    );

    const accessToken = res.data.accessToken;
    const user = res.data.user;

    if (!accessToken || !user) {
      throw new Error("Invalid auth response");
    }

    localStorage.setItem(TOKEN_KEY, accessToken);
    localStorage.setItem("user", JSON.stringify(user));
    setUser(user);

    return { accessToken, user };
  };

  /* ===================== LOGOUT ===================== */
  const logout = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("user");
    setUser(null);
  };

  /* ===================== ROLE HELPERS ===================== */
  const isStudent = user?.role === "student";
  const isTeacher = user?.role === "teacher";
  const isAdmin = user?.role === "admin";

  const getDashboardRoute = () => {
    if (isTeacher) return "/teacher/dashboard";
    if (isStudent) return "/dashboard";
    if (isAdmin) return "/admin/dashboard";
    return "/login";
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        isStudent,
        isTeacher,
        isAdmin,
        getDashboardRoute,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
